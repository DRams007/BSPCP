--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_member_status_on_renewal(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_member_status_on_renewal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Only proceed if renewal_due_date is being changed
  IF OLD.renewal_due_date IS DISTINCT FROM NEW.renewal_due_date THEN
    -- If renewal_due_date is in the past and member is currently active, mark as expired
    IF NEW.renewal_due_date < CURRENT_DATE AND OLD.member_status = 'active' THEN
      NEW.member_status := 'expired';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_activities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    activity_type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    details jsonb,
    related_entity character varying(50),
    related_id character varying(255),
    priority character varying(20) DEFAULT 'medium'::character varying,
    admin_id uuid,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT admin_activities_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])))
);


--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid,
    action character varying(100) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id character varying(255),
    old_values jsonb,
    new_values jsonb,
    ip_address character varying(45),
    user_agent text,
    status character varying(20) DEFAULT 'success'::character varying,
    details text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    resource character varying(100) NOT NULL,
    action character varying(100) NOT NULL,
    allowed boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: admin_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    salt character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'admin'::character varying,
    first_name character varying(100),
    last_name character varying(100),
    phone character varying(30),
    is_active boolean DEFAULT true,
    last_login timestamp with time zone,
    password_changed_at timestamp with time zone,
    login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    filename character varying(255) NOT NULL,
    filepath character varying(500) NOT NULL,
    filesize bigint NOT NULL,
    file_count integer DEFAULT 0,
    backup_type character varying(100) DEFAULT 'database'::character varying,
    formats text[] DEFAULT ARRAY['dump'::text, 'bak'::text, 'sql'::text],
    includes jsonb DEFAULT '[]'::jsonb,
    status character varying(50) DEFAULT 'active'::character varying,
    created_by character varying(255) DEFAULT 'BSPCP_admin'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp with time zone
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    counsellor_id uuid NOT NULL,
    client_name character varying(255) NOT NULL,
    phone_number character varying(30) NOT NULL,
    email character varying(255) NOT NULL,
    category character varying(255),
    needs text,
    session_type character varying(50),
    support_urgency character varying(50),
    booking_date date NOT NULL,
    booking_time time without time zone NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: bspcp_membership_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bspcp_membership_number_seq
    START WITH 175
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(30),
    inquiry_type character varying(50) NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    status character varying(50) DEFAULT 'unread'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT contact_messages_inquiry_type_check CHECK (((inquiry_type)::text = ANY ((ARRAY['general'::character varying, 'membership'::character varying, 'professional'::character varying, 'complaint'::character varying, 'media'::character varying, 'partnership'::character varying])::text[]))),
    CONSTRAINT contact_messages_status_check CHECK (((status)::text = ANY ((ARRAY['unread'::character varying, 'read'::character varying, 'replied'::character varying, 'archived'::character varying])::text[])))
);


--
-- Name: content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    status character varying(50) DEFAULT 'Draft'::character varying NOT NULL,
    content text,
    author character varying(255),
    location character varying(255),
    event_date date,
    event_time time without time zone,
    meta_description character varying(160),
    tags text,
    featured_image_path character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: content_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_images (
    id integer NOT NULL,
    content_id uuid NOT NULL,
    image_path character varying(255) NOT NULL,
    caption text,
    is_featured boolean DEFAULT false,
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: content_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_images_id_seq OWNED BY public.content_images.id;


--
-- Name: counsellor_notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.counsellor_notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    booking_notifications boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: member_authentication; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_authentication (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    username character varying(255) NOT NULL,
    password_hash character varying(255),
    salt character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: member_authentication_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_authentication_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_authentication_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_authentication_id_seq OWNED BY public.member_authentication.id;


--
-- Name: member_certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_certificates (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    file_path character varying(500) NOT NULL,
    original_filename character varying(255),
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: member_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_certificates_id_seq OWNED BY public.member_certificates.id;


--
-- Name: member_contact_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_contact_details (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    phone character varying(30),
    email character varying(255),
    website character varying(255),
    physical_address text,
    city character varying(100),
    postal_address text,
    emergency_contact character varying(255),
    emergency_phone character varying(30),
    show_email boolean DEFAULT true,
    show_phone boolean DEFAULT true,
    show_address boolean DEFAULT false
);


--
-- Name: member_contact_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_contact_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_contact_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_contact_details_id_seq OWNED BY public.member_contact_details.id;


--
-- Name: member_cpd; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_cpd (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    points integer NOT NULL,
    document_path character varying(255),
    status character varying(50) DEFAULT 'approved'::character varying,
    completion_date date,
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: member_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_documents (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    document_type character varying(100) NOT NULL,
    file_path character varying(255) NOT NULL,
    original_filename character varying(255) NOT NULL,
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: member_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_documents_id_seq OWNED BY public.member_documents.id;


--
-- Name: member_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_payments (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    amount numeric(10,2) NOT NULL,
    fee_type character varying(50) NOT NULL,
    proof_of_payment_path character varying(500),
    payment_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    verified_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT member_payments_fee_type_check CHECK (((fee_type)::text = ANY ((ARRAY['application_fee'::character varying, 'renewal_fee'::character varying])::text[])))
);


--
-- Name: member_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_payments_id_seq OWNED BY public.member_payments.id;


--
-- Name: member_personal_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_personal_documents (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    id_document_path character varying(500),
    profile_image_path character varying(500),
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: member_personal_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_personal_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_personal_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_personal_documents_id_seq OWNED BY public.member_personal_documents.id;


--
-- Name: member_professional_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_professional_details (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    occupation character varying(255),
    organization_name character varying(255),
    highest_qualification text,
    other_qualifications text,
    scholarly_publications text,
    specializations text[],
    employment_status character varying(50),
    years_experience character varying(50),
    bio text,
    title character varying(255),
    languages text[],
    session_types text[],
    availability character varying(100)
);


--
-- Name: member_professional_details_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_professional_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_professional_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_professional_details_id_seq OWNED BY public.member_professional_details.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    full_name character varying(255),
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    bspcp_membership_number character varying(50),
    id_number character varying(50) NOT NULL,
    date_of_birth date NOT NULL,
    gender character varying(10) NOT NULL,
    nationality character varying(100) NOT NULL,
    membership_type character varying(50) DEFAULT 'professional'::character varying,
    institution_name character varying(255),
    study_year character varying(50),
    counselling_coursework text,
    internship_supervisor_name character varying(255),
    internship_supervisor_license character varying(100),
    internship_supervisor_contact character varying(255),
    supervised_practice_hours character varying(50),
    application_status character varying(50) DEFAULT 'pending'::character varying,
    member_status character varying(50) DEFAULT 'pending'::character varying,
    review_comment text,
    cpd_document text,
    cpd_points integer DEFAULT 0,
    payment_proof_url character varying(500),
    payment_upload_token character varying(255),
    payment_status character varying(50) DEFAULT 'not_requested'::character varying,
    payment_requested_at timestamp with time zone,
    payment_uploaded_at timestamp with time zone,
    payment_verified_at timestamp with time zone,
    payment_rejected_at timestamp with time zone,
    payment_verified_by uuid,
    payment_request_count integer DEFAULT 0,
    counsellor_visible boolean DEFAULT true,
    renewal_date timestamp with time zone,
    renewal_status character varying(50) DEFAULT 'not_requested'::character varying,
    renewal_proof_url character varying(500),
    renewal_uploaded_at timestamp with time zone,
    renewal_token character varying(1000),
    renewal_token_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT members_membership_type_check CHECK (((membership_type)::text = ANY ((ARRAY['professional'::character varying, 'student'::character varying])::text[]))),
    CONSTRAINT members_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['not_requested'::character varying, 'requested'::character varying, 'uploaded'::character varying, 'verified'::character varying, 'rejected'::character varying])::text[]))),
    CONSTRAINT members_renewal_status_check CHECK (((renewal_status)::text = ANY ((ARRAY['not_requested'::character varying, 'requested'::character varying, 'uploaded'::character varying, 'verified'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: membership_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membership_categories (
    id integer NOT NULL,
    category_type character varying(50) NOT NULL,
    joining_fee numeric(10,2) NOT NULL,
    annual_fee numeric(10,2) NOT NULL,
    description text,
    requires_supervisor_info boolean DEFAULT false,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: membership_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.membership_categories_id_seq OWNED BY public.membership_categories.id;


--
-- Name: membership_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.membership_number_seq
    START WITH 175
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_recipients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    setting_name character varying(100) NOT NULL,
    setting_value boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: payment_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    admin_id uuid,
    action character varying(100) NOT NULL,
    details text,
    ip_address inet,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: payment_upload_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_upload_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    upload_token character varying(255),
    original_filename character varying(255),
    stored_filename character varying(255),
    file_size integer,
    file_type character varying(100),
    ip_address inet,
    user_agent text,
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_file_size CHECK (((file_size IS NULL) OR (file_size > 0))),
    CONSTRAINT valid_file_type CHECK (((file_type)::text = ANY ((ARRAY['pdf'::character varying, 'jpg'::character varying, 'jpeg'::character varying, 'png'::character varying])::text[]))),
    CONSTRAINT valid_filename CHECK ((length((COALESCE(original_filename, ''::character varying))::text) > 0))
);


--
-- Name: renewal_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.renewal_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    admin_id uuid,
    action character varying(100) NOT NULL,
    details text,
    ip_address inet,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: renewal_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.renewal_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    renewal_date date NOT NULL,
    expiry_date date NOT NULL,
    amount_paid numeric(10,2),
    proof_of_payment_url character varying(500),
    verified_by uuid,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: renewal_upload_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.renewal_upload_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    upload_token text,
    original_filename character varying(255),
    stored_filename text,
    file_size integer,
    file_type character varying(10),
    ip_address inet,
    user_agent text,
    uploaded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    role character varying(100),
    content text NOT NULL,
    rating integer NOT NULL,
    anonymous boolean DEFAULT false,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT testimonials_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: content_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_images ALTER COLUMN id SET DEFAULT nextval('public.content_images_id_seq'::regclass);


--
-- Name: member_authentication id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_authentication ALTER COLUMN id SET DEFAULT nextval('public.member_authentication_id_seq'::regclass);


--
-- Name: member_certificates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_certificates ALTER COLUMN id SET DEFAULT nextval('public.member_certificates_id_seq'::regclass);


--
-- Name: member_contact_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_contact_details ALTER COLUMN id SET DEFAULT nextval('public.member_contact_details_id_seq'::regclass);


--
-- Name: member_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents ALTER COLUMN id SET DEFAULT nextval('public.member_documents_id_seq'::regclass);


--
-- Name: member_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_payments ALTER COLUMN id SET DEFAULT nextval('public.member_payments_id_seq'::regclass);


--
-- Name: member_personal_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_personal_documents ALTER COLUMN id SET DEFAULT nextval('public.member_personal_documents_id_seq'::regclass);


--
-- Name: member_professional_details id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_professional_details ALTER COLUMN id SET DEFAULT nextval('public.member_professional_details_id_seq'::regclass);


--
-- Name: membership_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_categories ALTER COLUMN id SET DEFAULT nextval('public.membership_categories_id_seq'::regclass);


--
-- Data for Name: admin_activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_activities (id, activity_type, title, message, details, related_entity, related_id, priority, admin_id, is_read, created_at) FROM stdin;
6e249843-59d8-4102-a933-4935c2cfe962	application_approved	Application approved	Application for Ditiro Ramaduba was approved	{"newStatus": "approved", "memberName": "Ditiro Ramaduba", "reviewComment": "", "previousStatus": "approved"}	member	e9c40688-3242-42df-928d-bf7a5209a25d	high	cd2087c0-22ad-461e-91f3-dd89c26afd94	f	2025-12-08 19:21:33.28162+02
\.


--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_id, action, resource_type, resource_id, old_values, new_values, ip_address, user_agent, status, details, created_at) FROM stdin;
1263d954-d00e-4e17-a8d9-a77b1b6bceb3	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 14:43:49.651949+02
164c9af5-7efa-4409-9c88-b8538ee466bf	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 14:43:49.691783+02
7655055c-4669-42b5-955d-26c51e3fdcf6	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 14:43:49.730602+02
211d9211-4d3a-407e-87d3-a26b1996e900	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 14:45:16.171182+02
1698e262-f6ed-482c-8085-ea1eb32ee137	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 14:45:45.135225+02
d4065268-e08e-4f45-887a-5f7968ba9873	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 14:51:08.896004+02
c761c059-08cb-495d-b911-7c2018dd0960	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 17:55:26.502378+02
2f3c8ff7-883f-4f8d-88c5-ad2fed98a774	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 17:55:26.638505+02
aedc1c2f-ef26-46b1-a9f3-1cad0075fbf9	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 17:55:26.673026+02
1274b0b9-70b1-409e-ac6f-2d2105ba276f	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 17:55:53.227001+02
e02f9376-1179-4fc2-b5fa-035743a7e2b4	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 17:57:08.639905+02
2ce88757-e65d-460e-953b-60049fcc6494	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 17:58:02.36363+02
e3762cb9-c5f0-49a7-9bad-66439dcf087c	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 17:58:48.315743+02
ac37c532-9a0b-4528-8633-0b187cfec921	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 17:58:48.533733+02
4fb32524-10d0-452d-94d7-47b36b5f2e2c	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 17:59:31.727196+02
7a6e1bab-e796-4d53-82eb-63f5a89b6db4	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:00:13.29929+02
1a71d64c-a8de-41f8-9245-f8e1319b7eec	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:00:13.310012+02
a0f7f5dd-ee87-4c49-8693-cb12b3bbf685	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:00:13.340864+02
32b0fc6c-356f-4e9f-a019-62afd8ca5629	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:02:52.255593+02
d59a1172-a5e5-4b7d-bb83-6ed5dc349cf4	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:04:24.569909+02
221997f1-e2ee-4560-a8e1-04317760c00a	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:04:52.325768+02
8e7d4d7c-b7ff-406f-81d0-3fe613d30218	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:22:48.709024+02
48e2e384-2542-4036-9593-c867078ae336	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:23:51.29252+02
40309275-1276-4e49-a5ec-2a658333ab81	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:24:06.092616+02
3d2b61ea-7895-4714-a99f-1ca586a8a477	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:34:06.678512+02
74cb5317-8a6a-40cc-8d98-a5bf92ed6a90	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:35:19.246039+02
1f641944-a77b-48d5-9f5a-a82c4c0bc700	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:35:19.459251+02
a98fae60-9bdc-4067-bc8d-612ab868c4b9	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:35:19.506215+02
a6220443-d6ec-4188-887c-f4d7bbff4c50	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:46:31.822091+02
e25ba331-5c0d-4622-8fda-60bcf5d92088	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:46:33.831648+02
0af8b23b-92b0-440e-8837-a32b1da60ed6	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:47:03.092939+02
9822f7bd-b070-49ba-991e-1aa1578a78c0	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:51:10.041954+02
aebbd08f-dceb-4ae8-9626-25f4fa27b3ff	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:55:21.236146+02
5e21a2a1-b203-49af-a13d-2c68bd39d3ec	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 18:59:03.374528+02
7b83ad50-5228-4f98-8f86-ffceabf7e4fd	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 19:02:50.104943+02
55dba4b3-1b52-4e67-9e5e-9e49e07757d9	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 19:02:50.906034+02
caa8953a-bc47-41c2-819f-1f95c07ab99c	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 19:21:20.428384+02
60c97c58-b314-4683-83d0-8a34f6c46dae	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 19:21:59.459134+02
ab700e11-31a6-4c22-823c-3db82a62411e	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-08 19:22:29.965921+02
aadb0ac9-7811-4cc9-9dd0-6667f6787997	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:24:00.570477+02
b89c8d00-bb7f-4402-858c-98c789b148d1	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:24:09.182424+02
6681fe06-3505-4e0f-a0a9-38c849023881	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:24:16.090688+02
a7127df4-374e-4a96-b819-c454abd30a4e	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:24:39.668112+02
25a8f5e1-2ec4-4a73-9455-bbefccc68913	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:25:09.649884+02
61e9b7b1-9f70-46bf-9c39-81d963eb3dc0	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:25:39.656043+02
fc17837a-8630-4269-9d87-0ef472972b0d	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:26:09.649808+02
18dbdedc-4987-4def-bd89-796abb18b315	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:26:39.643547+02
dc500601-956c-46cd-a947-3c2dacb9c42d	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:27:09.657918+02
c257ed79-f78a-41c1-8f1a-8c5dde5a33c0	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:27:49.663675+02
82b25ace-8599-4773-a51d-4a4d7da26ee1	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:28:49.665193+02
fb729684-2b7e-4447-bd95-b24215763622	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:29:49.658992+02
f1f3423a-c995-43bb-aa94-b3b6e48e76ab	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:30:49.666575+02
8503d3be-dc21-414a-8990-733a46666b64	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:31:49.659322+02
43d45363-839a-4a33-92a6-fd4cf63e949b	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:32:49.650478+02
8fff32fe-f75b-47fd-b963-7c316fd081f3	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:33:49.665035+02
b8f6d51d-40e7-4fd6-b4c5-431ccad743ef	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:34:49.656623+02
d3b49b82-9eda-4394-b454-563e5de96956	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:35:49.67841+02
84fe8986-201b-4a5b-a9c4-cabec2e1d729	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:36:49.661511+02
12ff9323-6e64-445d-8724-47b3438a133e	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:37:49.654762+02
c84410a4-7ae2-41fa-a479-e87301571846	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:38:49.652726+02
52703d79-4589-4ea3-814a-06db393fcad0	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:39:49.671798+02
30cadd64-6497-4288-aaf5-e18c71489516	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:40:49.661338+02
0592dca0-4e4d-4baf-9663-d41c692f84c9	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:41:49.657753+02
2005a590-b997-4bfb-926e-f3943d315e5d	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:42:49.663398+02
e0388529-0256-4c7e-a915-c6111095fbac	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:43:49.749606+02
21d6313f-5817-4d83-925e-f4603e2fe1b2	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:44:49.656269+02
210f4e74-db3c-4fa3-8ba7-36ee98bd2a04	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:45:49.673451+02
04e66ffb-b1b9-4e98-8f14-97e3331f50f2	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:46:49.660716+02
0049a23b-72dc-4d30-8243-5e4c3084aebb	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:47:49.660581+02
ead48667-5895-4849-8544-6d7357992c97	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:48:49.667858+02
dc0738a3-45b5-4e1d-9196-56aaaf4f7bff	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:49:49.662815+02
6a0b704f-d02e-49f9-abd4-5930519847a2	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:50:49.6529+02
2e1ab932-c436-4344-926d-812c2f0abe89	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:51:49.669309+02
34da8090-7be7-4b81-a7c9-39e6db886da1	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:52:49.662422+02
4d7bbfbf-63ef-4b2c-843e-27b7ec9bab3b	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:53:49.671141+02
cfeae7bc-a22a-4d49-972d-90e2fcfe4cf7	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:54:49.654136+02
e7109b5e-f3b0-4414-b335-24fe2866f77b	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:55:49.660907+02
921e2a32-7aae-4937-9730-6c230d3c1e89	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:56:49.667151+02
ac08959a-1dfd-4f24-b43e-3abcc597af6a	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:57:49.6585+02
471dc7ba-fd12-4167-b452-91189caef537	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:58:49.650945+02
a7ba1372-f7dc-4e69-b61b-47c7e5b73578	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 19:59:49.661578+02
84e9da32-a8e9-4297-807f-fc0f8fa1eeab	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 20:00:49.747017+02
256c0786-a5ba-4d5b-b5f0-b1f22808ca1d	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 20:01:49.667647+02
65116f56-5640-46ac-9773-a1944f35f240	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 20:02:49.755504+02
7b5bfc68-96d8-482b-a111-47b6e03168a1	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 20:03:49.664699+02
30856cbf-9d66-477e-899b-57d7c0ca3881	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 20:04:49.661801+02
6521da08-3451-48c3-ad8c-8529e5b86672	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 20:05:49.668114+02
cab6fa67-f32b-4444-8909-2c822d0838f8	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-08 20:06:49.65901+02
e2c0e63b-2393-4cfb-b784-e93de1b8b5ce	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-09 09:54:46.237935+02
4dcc2351-ad4d-4bb6-b3d8-de0a6d959bb8	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-09 09:54:46.336336+02
43aed003-d8d7-403f-ab68-f731e320a409	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-09 09:54:46.37202+02
a0f3c84a-be3c-4ddc-aa2b-c2dd14577257	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-09 10:00:19.66823+02
400cc1b6-7dc2-467c-9a6f-ea89bb78bb6d	cd2087c0-22ad-461e-91f3-dd89c26afd94	profile_view	own_profile	cd2087c0-22ad-461e-91f3-dd89c26afd94	\N	\N	\N	\N	success	\N	2025-12-09 10:00:19.6808+02
d2dc6339-0af4-44c2-b0e4-3997a3efe358	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-09 10:00:19.765457+02
cfaffa66-ee25-4023-953a-d2e60467e651	cd2087c0-22ad-461e-91f3-dd89c26afd94	dashboard_access	system	\N	\N	\N	\N	\N	success	Accessed admin dashboard statistics	2025-12-09 10:03:40.856193+02
\.


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_permissions (id, admin_id, resource, action, allowed, created_at) FROM stdin;
55244fcc-0f16-418f-8506-db8df891b44b	cd2087c0-22ad-461e-91f3-dd89c26afd94	members	manage	t	2025-12-08 12:04:16.785893+02
80d8e3e8-6267-4b90-bf16-a72c6d1e599c	cd2087c0-22ad-461e-91f3-dd89c26afd94	applications	manage	t	2025-12-08 12:04:16.792035+02
2e618107-9888-43be-b799-23cfd52a80a3	cd2087c0-22ad-461e-91f3-dd89c26afd94	content	manage	t	2025-12-08 12:04:16.792927+02
fefdee1a-df00-4bd0-bf37-90d20675d2b6	cd2087c0-22ad-461e-91f3-dd89c26afd94	testimonials	manage	t	2025-12-08 12:04:16.793755+02
8775614e-9496-4469-b2b6-9ff64c9f0201	cd2087c0-22ad-461e-91f3-dd89c26afd94	bookings	manage	t	2025-12-08 12:04:16.794755+02
637665d8-65a5-4f3e-823f-c8c0e1e7791a	cd2087c0-22ad-461e-91f3-dd89c26afd94	backups	manage	t	2025-12-08 12:04:16.795651+02
6c98d709-f270-44d6-a9cd-3452109321e3	cd2087c0-22ad-461e-91f3-dd89c26afd94	admin_users	manage	t	2025-12-08 12:04:16.796658+02
7a9d9a58-9a2e-4f66-b162-6374ad016e36	cd2087c0-22ad-461e-91f3-dd89c26afd94	reports	manage	t	2025-12-08 12:04:16.797599+02
6f29fea6-3d81-47e8-8039-a0c1b191bdf0	cd2087c0-22ad-461e-91f3-dd89c26afd94	settings	manage	t	2025-12-08 12:04:16.798538+02
02afa9c4-dc71-4fb2-ae28-89186d962601	cd2087c0-22ad-461e-91f3-dd89c26afd94	notifications	manage	t	2025-12-08 12:04:16.799287+02
\.


--
-- Data for Name: admin_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_sessions (id, admin_id, token_hash, ip_address, user_agent, expires_at, created_at) FROM stdin;
a80a5c70-5c3a-485a-88b2-7ba86e2153a9	cd2087c0-22ad-461e-91f3-dd89c26afd94	a00be0daf2a3a3590d9a74a625c61b0b3028d1ab829329db2d84070c15cdc62f	192.168.1.124	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-08 16:43:49.514+02	2025-12-08 14:43:49.515746+02
6aece174-c98e-4ac3-97a1-d96a3b860d1f	cd2087c0-22ad-461e-91f3-dd89c26afd94	40c962b4a3a175a6e448c4f66aff6342f04439e1a0132617d824d1a5ba0482d7	192.168.8.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-08 19:55:26.362+02	2025-12-08 17:55:26.363849+02
e27646a8-1a0f-434d-acd5-641d0fc6c9eb	cd2087c0-22ad-461e-91f3-dd89c26afd94	75588a2495a019111106a5052043e76c00848fb71a64214639c64952b932d5c1	192.168.8.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-08 19:57:08.547+02	2025-12-08 17:57:08.547781+02
07a59b5e-1969-42ac-b612-ef9a0a729cbd	cd2087c0-22ad-461e-91f3-dd89c26afd94	e79034f6d493cc51bf46855e5a8e1dde6ddff69f82a734b995a57cffad9ebe03	192.168.8.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-08 20:22:48.321+02	2025-12-08 18:22:48.322522+02
3ebd0366-2653-4241-90f7-bf76daedc3d5	cd2087c0-22ad-461e-91f3-dd89c26afd94	e7ff68215fee781cf527e1bab57268a9471e83243e0b51ab28a77a01ae0c8bab	192.168.1.124	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-09 11:54:46.017+02	2025-12-09 09:54:46.020541+02
\.


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admins (id, username, email, password_hash, salt, role, first_name, last_name, phone, is_active, last_login, password_changed_at, login_attempts, locked_until, created_by, created_at, updated_at) FROM stdin;
cd2087c0-22ad-461e-91f3-dd89c26afd94	bsncp_admin	bspcpemail@gmail.com	$2b$12$Hpxy0FJ/TXFpMz0YTLwP/OHBUenCqmqZk01LlrHTEXFGSFB4iSGVu	$2b$12$Hpxy0FJ/TXFpMz0YTLwP/O	super_admin	System	Administrator	\N	t	2025-12-09 09:54:45.99858+02	\N	0	\N	\N	2025-12-08 12:04:16.775029+02	2025-12-08 12:04:16.775029+02
\.


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_records (id, filename, filepath, filesize, file_count, backup_type, formats, includes, status, created_by, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, counsellor_id, client_name, phone_number, email, category, needs, session_type, support_urgency, booking_date, booking_time, status, created_at) FROM stdin;
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_messages (id, first_name, last_name, email, phone, inquiry_type, subject, message, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content (id, title, slug, type, status, content, author, location, event_date, event_time, meta_description, tags, featured_image_path, created_at) FROM stdin;
\.


--
-- Data for Name: content_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.content_images (id, content_id, image_path, caption, is_featured, uploaded_at) FROM stdin;
\.


--
-- Data for Name: counsellor_notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.counsellor_notification_preferences (id, member_id, booking_notifications, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_authentication; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_authentication (id, member_id, username, password_hash, salt, created_at) FROM stdin;
1	e9c40688-3242-42df-928d-bf7a5209a25d	dramaduba	$2b$10$JmvFYGVoDiw1c84/eoL8ROqUSOYB.rVYJ6fhqh0aFwL4agAGZY9EC	$2b$10$JmvFYGVoDiw1c84/eoL8RO	2025-12-08 19:22:07.646465+02
\.


--
-- Data for Name: member_certificates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_certificates (id, member_id, file_path, original_filename, uploaded_at) FROM stdin;
2	e9c40688-3242-42df-928d-bf7a5209a25d	C:\\Users\\ditir\\Downloads\\BSPCP\\server\\uploads\\1765209415326-OIG.__XpLELmGQ0Nh_.EpSeD.jpg	OIG.__XpLELmGQ0Nh_.EpSeD.jpg	2025-12-08 17:56:55.383488+02
\.


--
-- Data for Name: member_contact_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_contact_details (id, member_id, phone, email, website, physical_address, city, postal_address, emergency_contact, emergency_phone, show_email, show_phone, show_address) FROM stdin;
2	e9c40688-3242-42df-928d-bf7a5209a25d	71412323	Ditirotr@gmail.com	\N	Po Box 30,Shoshong\r\nShoshong	Gaborone	\N	\N	\N	t	t	f
\.


--
-- Data for Name: member_cpd; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_cpd (id, member_id, title, points, document_path, status, completion_date, uploaded_at) FROM stdin;
\.


--
-- Data for Name: member_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_documents (id, member_id, document_type, file_path, original_filename, uploaded_at) FROM stdin;
\.


--
-- Data for Name: member_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_payments (id, member_id, first_name, last_name, amount, fee_type, proof_of_payment_path, payment_date, verified_by, created_at) FROM stdin;
2	e9c40688-3242-42df-928d-bf7a5209a25d	Ditiro	Ramaduba	200.00	application_fee	\N	2025-12-08 18:04:57.030693+02	cd2087c0-22ad-461e-91f3-dd89c26afd94	2025-12-08 18:04:57.030693+02
3	e9c40688-3242-42df-928d-bf7a5209a25d	Ditiro	Ramaduba	200.00	application_fee	\N	2025-12-08 18:24:09.886609+02	cd2087c0-22ad-461e-91f3-dd89c26afd94	2025-12-08 18:24:09.886609+02
\.


--
-- Data for Name: member_personal_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_personal_documents (id, member_id, id_document_path, profile_image_path, uploaded_at) FROM stdin;
2	e9c40688-3242-42df-928d-bf7a5209a25d	C:\\Users\\ditir\\Downloads\\BSPCP\\server\\uploads\\1765209415324-OIG.__XpLELmGQ0Nh_.EpSeD.jpg	\N	2025-12-08 17:56:55.383488+02
\.


--
-- Data for Name: member_professional_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_professional_details (id, member_id, occupation, organization_name, highest_qualification, other_qualifications, scholarly_publications, specializations, employment_status, years_experience, bio, title, languages, session_types, availability) FROM stdin;
2	e9c40688-3242-42df-928d-bf7a5209a25d	Clinical Psychologist	Doe ltd	Masters	\N	\N	{"Stress Management"}	employed	2	\N	Dr	{}	{In-Person,"Online Video","Phone Sessions"}	\N
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, full_name, first_name, last_name, bspcp_membership_number, id_number, date_of_birth, gender, nationality, membership_type, institution_name, study_year, counselling_coursework, internship_supervisor_name, internship_supervisor_license, internship_supervisor_contact, supervised_practice_hours, application_status, member_status, review_comment, cpd_document, cpd_points, payment_proof_url, payment_upload_token, payment_status, payment_requested_at, payment_uploaded_at, payment_verified_at, payment_rejected_at, payment_verified_by, payment_request_count, counsellor_visible, renewal_date, renewal_status, renewal_proof_url, renewal_uploaded_at, renewal_token, renewal_token_expires_at, created_at) FROM stdin;
e9c40688-3242-42df-928d-bf7a5209a25d	Ditiro Ramaduba	Ditiro	Ramaduba	BSPCP 0175	54645654641	2025-12-08	male	Motswana	professional	\N	\N	\N	\N	\N	\N	\N	approved	active		\N	0	uploads/1765211038730-OIG.D.KnZo_xI2ueyiH4AP33.jpg	\N	verified	2025-12-08 18:23:46.496451+02	2025-12-08 18:23:58.739605+02	2025-12-08 18:24:09.886609+02	\N	\N	0	t	2026-12-08 19:21:28.221584+02	not_requested	\N	\N	\N	\N	2025-12-08 17:56:55.383488+02
\.


--
-- Data for Name: membership_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membership_categories (id, category_type, joining_fee, annual_fee, description, requires_supervisor_info, active, created_at) FROM stdin;
1	professional	50.00	150.00	Full professional membership for qualified counsellors with Bachelor's degree minimum	f	t	2025-12-08 12:04:05.549703+02
2	student	50.00	150.00	Student membership for counselling trainees still in training programs	t	t	2025-12-08 12:04:05.549703+02
\.


--
-- Data for Name: notification_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_recipients (id, email, is_active, created_at, updated_at) FROM stdin;
8ded79e2-990c-4957-85da-34a5a0fdbe76	bspcpemail@gmail.com	t	2025-12-08 12:04:05.522947+02	2025-12-08 12:04:05.522947+02
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_settings (id, setting_name, setting_value, created_at, updated_at) FROM stdin;
3f7f12f4-3365-4fcb-aa44-524c078b8037	notifications_enabled	t	2025-12-08 12:04:05.526724+02	2025-12-08 12:04:05.526724+02
\.


--
-- Data for Name: payment_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_audit_log (id, member_id, admin_id, action, details, ip_address, created_at) FROM stdin;
e4704d54-45db-4750-a4ce-f487ee16ac1d	e9c40688-3242-42df-928d-bf7a5209a25d	cd2087c0-22ad-461e-91f3-dd89c26afd94	payment_requested	Payment requested by admin System Administrator	192.168.8.118	2025-12-08 17:57:15.237173+02
4651715f-6e40-4226-8548-0f49408858e8	e9c40688-3242-42df-928d-bf7a5209a25d	cd2087c0-22ad-461e-91f3-dd89c26afd94	payment_requested	Payment requested by admin System Administrator	192.168.8.118	2025-12-08 18:00:47.856827+02
c3635f88-69c0-4b50-a315-805651b46a4e	e9c40688-3242-42df-928d-bf7a5209a25d	cd2087c0-22ad-461e-91f3-dd89c26afd94	payment_requested	Payment requested by admin System Administrator	192.168.8.118	2025-12-08 18:04:10.655699+02
76b75e3f-4f6d-4047-8791-d495f39db360	e9c40688-3242-42df-928d-bf7a5209a25d	\N	payment_uploaded	Payment proof uploaded by member Ditiro Ramaduba	192.168.8.118	2025-12-08 18:04:42.294658+02
d4e77cf0-fcb5-4d81-8319-1e73440083a6	e9c40688-3242-42df-928d-bf7a5209a25d	cd2087c0-22ad-461e-91f3-dd89c26afd94	payment_verified	Payment verified by admin System Administrator	192.168.8.118	2025-12-08 18:04:57.030693+02
42e92bcc-5886-44bd-bb91-0dc46cdf820f	e9c40688-3242-42df-928d-bf7a5209a25d	cd2087c0-22ad-461e-91f3-dd89c26afd94	payment_requested	Payment requested by admin System Administrator	192.168.8.118	2025-12-08 18:23:46.496451+02
da94f3a6-ac7d-4d0d-87cf-af88f706bf25	e9c40688-3242-42df-928d-bf7a5209a25d	\N	payment_uploaded	Payment proof uploaded by member Ditiro Ramaduba	192.168.8.118	2025-12-08 18:23:58.744513+02
dbe15dba-bfe1-4a59-ba24-4f6a4f606f89	e9c40688-3242-42df-928d-bf7a5209a25d	cd2087c0-22ad-461e-91f3-dd89c26afd94	payment_verified	Payment verified by admin System Administrator	192.168.8.118	2025-12-08 18:24:09.886609+02
\.


--
-- Data for Name: payment_upload_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_upload_logs (id, member_id, upload_token, original_filename, stored_filename, file_size, file_type, ip_address, user_agent, uploaded_at) FROM stdin;
2e8864a7-2842-4bdb-81d1-5c78154f2f75	e9c40688-3242-42df-928d-bf7a5209a25d	\N	IAM Solution Design.pdf	uploads/1765209882221-IAM Solution Design.pdf	108866	pdf	192.168.8.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-08 18:04:42.290678+02
358a6fe2-193a-4f54-a677-70d0ebe68acc	e9c40688-3242-42df-928d-bf7a5209a25d	\N	OIG.D.KnZo_xI2ueyiH4AP33.jpg	uploads/1765211038730-OIG.D.KnZo_xI2ueyiH4AP33.jpg	145176	jpeg	192.168.8.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-08 18:23:58.74278+02
\.


--
-- Data for Name: renewal_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.renewal_audit_log (id, member_id, admin_id, action, details, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: renewal_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.renewal_history (id, member_id, renewal_date, expiry_date, amount_paid, proof_of_payment_url, verified_by, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: renewal_upload_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.renewal_upload_logs (id, member_id, upload_token, original_filename, stored_filename, file_size, file_type, ip_address, user_agent, uploaded_at) FROM stdin;
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials (id, name, email, role, content, rating, anonymous, status, created_at) FROM stdin;
\.


--
-- Name: bspcp_membership_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bspcp_membership_number_seq', 175, true);


--
-- Name: content_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_images_id_seq', 1, false);


--
-- Name: member_authentication_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_authentication_id_seq', 1, true);


--
-- Name: member_certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_certificates_id_seq', 2, true);


--
-- Name: member_contact_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_contact_details_id_seq', 2, true);


--
-- Name: member_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_documents_id_seq', 1, false);


--
-- Name: member_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_payments_id_seq', 3, true);


--
-- Name: member_personal_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_personal_documents_id_seq', 2, true);


--
-- Name: member_professional_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_professional_details_id_seq', 2, true);


--
-- Name: membership_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_categories_id_seq', 2, true);


--
-- Name: membership_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.membership_number_seq', 185, true);


--
-- Name: admin_activities admin_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_activities
    ADD CONSTRAINT admin_activities_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_sessions admin_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_pkey PRIMARY KEY (id);


--
-- Name: admin_sessions admin_sessions_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: admins admins_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_key UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: admins admins_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_username_key UNIQUE (username);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: content_images content_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_images
    ADD CONSTRAINT content_images_pkey PRIMARY KEY (id);


--
-- Name: content content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT content_pkey PRIMARY KEY (id);


--
-- Name: counsellor_notification_preferences counsellor_notification_preferences_member_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counsellor_notification_preferences
    ADD CONSTRAINT counsellor_notification_preferences_member_id_key UNIQUE (member_id);


--
-- Name: counsellor_notification_preferences counsellor_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counsellor_notification_preferences
    ADD CONSTRAINT counsellor_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: member_authentication member_authentication_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_authentication
    ADD CONSTRAINT member_authentication_pkey PRIMARY KEY (id);


--
-- Name: member_authentication member_authentication_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_authentication
    ADD CONSTRAINT member_authentication_username_key UNIQUE (username);


--
-- Name: member_certificates member_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_certificates
    ADD CONSTRAINT member_certificates_pkey PRIMARY KEY (id);


--
-- Name: member_contact_details member_contact_details_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_contact_details
    ADD CONSTRAINT member_contact_details_email_key UNIQUE (email);


--
-- Name: member_contact_details member_contact_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_contact_details
    ADD CONSTRAINT member_contact_details_pkey PRIMARY KEY (id);


--
-- Name: member_cpd member_cpd_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_cpd
    ADD CONSTRAINT member_cpd_pkey PRIMARY KEY (id);


--
-- Name: member_documents member_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_documents
    ADD CONSTRAINT member_documents_pkey PRIMARY KEY (id);


--
-- Name: member_payments member_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_payments
    ADD CONSTRAINT member_payments_pkey PRIMARY KEY (id);


--
-- Name: member_personal_documents member_personal_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_personal_documents
    ADD CONSTRAINT member_personal_documents_pkey PRIMARY KEY (id);


--
-- Name: member_professional_details member_professional_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_professional_details
    ADD CONSTRAINT member_professional_details_pkey PRIMARY KEY (id);


--
-- Name: members members_payment_upload_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_payment_upload_token_key UNIQUE (payment_upload_token);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: members members_renewal_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_renewal_token_key UNIQUE (renewal_token);


--
-- Name: membership_categories membership_categories_category_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_categories
    ADD CONSTRAINT membership_categories_category_type_key UNIQUE (category_type);


--
-- Name: membership_categories membership_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membership_categories
    ADD CONSTRAINT membership_categories_pkey PRIMARY KEY (id);


--
-- Name: notification_recipients notification_recipients_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_email_key UNIQUE (email);


--
-- Name: notification_recipients notification_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_recipients
    ADD CONSTRAINT notification_recipients_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_setting_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_setting_name_key UNIQUE (setting_name);


--
-- Name: payment_audit_log payment_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_audit_log
    ADD CONSTRAINT payment_audit_log_pkey PRIMARY KEY (id);


--
-- Name: payment_upload_logs payment_upload_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_upload_logs
    ADD CONSTRAINT payment_upload_logs_pkey PRIMARY KEY (id);


--
-- Name: renewal_audit_log renewal_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.renewal_audit_log
    ADD CONSTRAINT renewal_audit_log_pkey PRIMARY KEY (id);


--
-- Name: renewal_history renewal_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.renewal_history
    ADD CONSTRAINT renewal_history_pkey PRIMARY KEY (id);


--
-- Name: renewal_upload_logs renewal_upload_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.renewal_upload_logs
    ADD CONSTRAINT renewal_upload_logs_pkey PRIMARY KEY (id);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_activities_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_activities_created_at ON public.admin_activities USING btree (created_at DESC);


--
-- Name: idx_admin_activities_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_activities_priority ON public.admin_activities USING btree (priority);


--
-- Name: idx_admin_activities_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_activities_type ON public.admin_activities USING btree (activity_type);


--
-- Name: idx_member_payments_fee_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_member_payments_fee_type ON public.member_payments USING btree (fee_type);


--
-- Name: idx_member_payments_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_member_payments_member_id ON public.member_payments USING btree (member_id);


--
-- Name: idx_member_payments_payment_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_member_payments_payment_date ON public.member_payments USING btree (payment_date DESC);


--
-- Name: idx_members_payment_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_payment_status ON public.members USING btree (payment_status);


--
-- Name: idx_members_payment_status_requested; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_payment_status_requested ON public.members USING btree (payment_status) WHERE ((payment_status)::text = 'uploaded'::text);


--
-- Name: idx_members_payment_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_payment_token ON public.members USING btree (payment_upload_token);


--
-- Name: idx_members_payment_verified_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_members_payment_verified_by ON public.members USING btree (payment_verified_by);


--
-- Name: idx_payment_audit_log_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_audit_log_action ON public.payment_audit_log USING btree (action);


--
-- Name: idx_payment_audit_log_admin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_audit_log_admin_id ON public.payment_audit_log USING btree (admin_id);


--
-- Name: idx_payment_audit_log_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_audit_log_member_id ON public.payment_audit_log USING btree (member_id);


--
-- Name: idx_payment_upload_logs_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_upload_logs_member_id ON public.payment_upload_logs USING btree (member_id);


--
-- Name: idx_payment_upload_logs_upload_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_upload_logs_upload_token ON public.payment_upload_logs USING btree (upload_token);


--
-- Name: admin_activities admin_activities_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_activities
    ADD CONSTRAINT admin_activities_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;


--
-- Name: admin_audit_log admin_audit_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE SET NULL;


--
-- Name: admin_permissions admin_permissions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: admin_sessions admin_sessions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_counsellor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_counsellor_id_fkey FOREIGN KEY (counsellor_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: counsellor_notification_preferences counsellor_notification_preferences_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counsellor_notification_preferences
    ADD CONSTRAINT counsellor_notification_preferences_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_authentication member_authentication_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_authentication
    ADD CONSTRAINT member_authentication_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_certificates member_certificates_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_certificates
    ADD CONSTRAINT member_certificates_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_contact_details member_contact_details_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_contact_details
    ADD CONSTRAINT member_contact_details_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_cpd member_cpd_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_cpd
    ADD CONSTRAINT member_cpd_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_payments member_payments_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_payments
    ADD CONSTRAINT member_payments_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_payments member_payments_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_payments
    ADD CONSTRAINT member_payments_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.admins(id);


--
-- Name: member_personal_documents member_personal_documents_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_personal_documents
    ADD CONSTRAINT member_personal_documents_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_professional_details member_professional_details_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_professional_details
    ADD CONSTRAINT member_professional_details_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: members members_payment_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_payment_verified_by_fkey FOREIGN KEY (payment_verified_by) REFERENCES public.admins(id);


--
-- Name: payment_audit_log payment_audit_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_audit_log
    ADD CONSTRAINT payment_audit_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id);


--
-- Name: payment_audit_log payment_audit_log_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_audit_log
    ADD CONSTRAINT payment_audit_log_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: payment_upload_logs payment_upload_logs_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_upload_logs
    ADD CONSTRAINT payment_upload_logs_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: renewal_audit_log renewal_audit_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.renewal_audit_log
    ADD CONSTRAINT renewal_audit_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id);


--
-- Name: renewal_audit_log renewal_audit_log_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.renewal_audit_log
    ADD CONSTRAINT renewal_audit_log_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- PostgreSQL database dump complete
--

